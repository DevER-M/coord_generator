This programme can generate random coordinations 
very simple and easy
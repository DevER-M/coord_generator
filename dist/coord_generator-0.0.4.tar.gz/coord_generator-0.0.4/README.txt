This programme can generate random coordinations 
very simple and easy.

view code at : https://github.com/DevER-M/coord_generator